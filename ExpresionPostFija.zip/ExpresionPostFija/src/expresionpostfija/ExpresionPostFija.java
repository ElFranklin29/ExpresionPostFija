package expresionpostfija;

import java.util.Stack;

public class ExpresionPostFija {

    private String inFija;
    private Stack<Character> operadores = new <Character>Stack();
    private char[] expresionPos;
    private char resultado;

    public ExpresionPostFija(String inFija, char[] expresionPos, char resultado) {
        this.inFija = inFija;
        this.expresionPos = expresionPos;
        this.resultado = resultado;
    }

    public ExpresionPostFija() {
        this.inFija = "";
        this.expresionPos = new char[0];
        this.resultado = 0;
    }

    public char getResultado() {
        return resultado;
    }

    public void setResultado(char resultado) {
        this.resultado = resultado;
    }

    public char[] getExpresionPos() {
        return expresionPos;
    }

    public void setExpresionPos(char[] expresionPos) {
        this.expresionPos = expresionPos;
    }

    public String getInFija() {
        return inFija;
    }

    public void setInFija(String inFija) {
        this.inFija = inFija;
    }

    public Stack<Character> getOperadores() {
        return operadores;
    }

    public void setOperadores(Stack<Character> operadores) {
        this.operadores = operadores;
    }

    public void postFija() {
        expresionPos = new char[inFija.length()];
        int k = 0;

        for (int i = 0; i < inFija.length(); i++) {

            char caracter = inFija.charAt(i);

            if (validarCaracter(caracter) == true) {

                //validar si la pila esta vacia
                if (operadores.isEmpty()) {
                    operadores.push(caracter);
                    //realizar comparaciones de prioridad
                } else {
                    if (prioridadOperador(caracter) > prioridadOperador(operadores.peek())) {
                        operadores.push(caracter);
                    } else {
                        while (!operadores.isEmpty() && !(prioridadOperador(caracter) > prioridadOperador(operadores.peek()))) {
                            expresionPos[k] = operadores.pop();
                            k++;
                        }
                        operadores.push(caracter);
                    }

                }

            } else {
                 
                 
                 if (caracter == ')') {
                    if (operadores.peek() == '(') {
                        operadores.pop();
                    } else {
                        expresionPos[k] = operadores.pop();
                        k++;
                    }

                }
                 
                 
                    expresionPos[k] = caracter;
                    k++;

            }
            

        }
        while (!operadores.empty()) {
            expresionPos[k] = operadores.pop();
            k++;

        }

        System.out.println(expresionPos);
    }

    public boolean validarCaracter(char caracter) {
        return caracter == '+' || caracter == '-' || caracter == '*' || caracter == '/' || caracter == '^';

    }

    public int prioridadOperador(char caracter) {
        switch (caracter) {
            case '+':
                return 0;
            case '-':
                return 0;
            case '*':
                return 1;
            case '/':
                return 1;
            case '(':
                return -1;
            default:
                return 2;
        }

    }

}
